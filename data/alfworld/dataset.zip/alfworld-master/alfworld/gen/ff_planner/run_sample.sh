#!/bin/bash
./ff -o samples/PutTask_domain.pddl -s 5 -f samples/problem_0_0.pddl
