from alfworld.agents.controller.oracle import OracleAgent
from alfworld.agents.controller.oracle_astar import OracleAStarAgent
from alfworld.agents.controller.mrcnn import MaskRCNNAgent
from alfworld.agents.controller.mrcnn_astar import MaskRCNNAStarAgent